package me.wairesd;

import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;

public class PlayerJoinQuitListener implements Listener {

    private final PassportManager passportManager;

    public PlayerJoinQuitListener(PassportManager passportManager) {
        this.passportManager = passportManager;
    }

    @EventHandler
    public void onPlayerJoin(PlayerJoinEvent event) {
        var player = event.getPlayer();
        passportManager.initPassportIfNeeded(player);
        passportManager.getJoinTimes().put(player.getUniqueId(), System.currentTimeMillis());
    }

    @EventHandler
    public void onPlayerQuit(PlayerQuitEvent event) {
        passportManager.updatePlayTime(event.getPlayer());
    }
}
