package me.wairesd;

import org.bukkit.configuration.file.FileConfiguration;

import java.io.File;
import java.sql.*;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.ThreadLocalRandom;

public class DatabaseManager {
    private Connection connection;
    private final File dataFolder;
    private final FileConfiguration config;

    public DatabaseManager(File dataFolder, FileConfiguration config) {
        this.dataFolder = dataFolder;
        this.config = config;
    }

    public void setupDatabase() {
        try {
            File dbFile = new File(System.getProperty("user.dir"), "databases/Passport.db");
            if (!dbFile.getParentFile().exists()) dbFile.getParentFile().mkdirs();
            connection = DriverManager.getConnection("jdbc:sqlite:" + dbFile);
            try (PreparedStatement stmt = connection.prepareStatement(
                    "CREATE TABLE IF NOT EXISTS passports (" +
                            "player TEXT PRIMARY KEY, age TEXT, gender TEXT, vk TEXT, tg TEXT, ds TEXT, " +
                            "firstJoin TEXT, playTime TEXT, passportNumber TEXT)")) {
                stmt.execute();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void closeDatabase() {
        try {
            if (connection != null && !connection.isClosed()) connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public Map<String, String> getPassportData(String player) {
        Map<String, String> data = new HashMap<>();
        try (PreparedStatement ps = connection.prepareStatement("SELECT * FROM passports WHERE player = ?")) {
            ps.setString(1, player);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    data.put("age", Objects.toString(rs.getString("age"), ""));
                    data.put("gender", Objects.toString(rs.getString("gender"), ""));
                    data.put("vk", Objects.toString(rs.getString("vk"), ""));
                    data.put("tg", Objects.toString(rs.getString("tg"), ""));
                    data.put("ds", Objects.toString(rs.getString("ds"), ""));
                    data.put("firstJoin", Objects.toString(rs.getString("firstJoin"), ""));
                    data.put("playTime", Objects.toString(rs.getString("playTime"), ""));
                    data.put("passportNumber", Objects.toString(rs.getString("passportNumber"), ""));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return data;
    }

    public void updatePassportData(String player, String key, String value) {
        try {
            String query;
            if (key.equals("playTime")) {
                query = "UPDATE passports SET playTime = ? WHERE player = ?";
            } else {
                query = "INSERT INTO passports (player, " + key + ", playTime) VALUES (?, ?, '0') " +
                        "ON CONFLICT(player) DO UPDATE SET " + key + " = excluded." + key;
            }
            try (PreparedStatement stmt = connection.prepareStatement(query)) {
                if (key.equals("playTime")) {
                    stmt.setString(1, value);
                    stmt.setString(2, player);
                } else {
                    stmt.setString(1, player);
                    stmt.setString(2, value);
                }
                stmt.executeUpdate();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void insertPassport(String player, String firstJoin, String passportNumber) {
        try (PreparedStatement stmt = connection.prepareStatement(
                "INSERT INTO passports (player, firstJoin, passportNumber, playTime) VALUES (?, ?, ?, '0')")) {
            stmt.setString(1, player);
            stmt.setString(2, firstJoin);
            stmt.setString(3, passportNumber);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void removePassport(String target) throws SQLException {
        try (PreparedStatement ps = connection.prepareStatement("DELETE FROM passports WHERE player = ?")) {
            ps.setString(1, target);
            ps.executeUpdate();
        }
    }

    public String generatePassportNumber() {
        return String.format("#%010d", ThreadLocalRandom.current().nextInt(1_000_000_000));
    }
}
