package me.wairesd;

import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;

import java.sql.SQLException;
import java.util.Locale;

public class AdminPassportCommand implements CommandExecutor {

    private final PassportManager passportManager;
    private final PassportPlugin plugin; // our main plugin
    private final DiscordBotManager discordBotManager;
    private FileConfiguration settingsConfig; // config from settings.yml

    public AdminPassportCommand(PassportManager passportManager, PassportPlugin plugin, DiscordBotManager discordBotManager) {
        this.passportManager = passportManager;
        this.plugin = plugin;
        this.discordBotManager = discordBotManager;
        this.settingsConfig = plugin.getSettingsConfig();
    }

    private String t(String key) {
        return MessageUtils.getMessage(passportManager.getMessagesConfig(), key);
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("bat.passport.admin.reload") &&
                !sender.hasPermission("bat.passport.admin.remove.pass")) {
            sender.sendMessage(t("messages.no-permission"));
            return true;
        }
        if (args.length == 0) {
            sender.sendMessage(t("messages.use-adminpassport"));
            return true;
        }
        String sub = args[0].toLowerCase(Locale.ROOT);
        if (sub.equals("reload")) {
            // Reload external configs (messages.yml and settings.yml)
            plugin.reloadAllConfigs();
            this.settingsConfig = plugin.getSettingsConfig();
            passportManager.setMessagesConfig(plugin.getMessagesConfig());
            String newToken = settingsConfig.getString("discord.token", "");
            if (discordBotManager != null) {
                discordBotManager.updateToken(newToken);
            }
            sender.sendMessage(ChatColor.translateAlternateColorCodes('&', "&aConfig reloaded!"));
        } else if (sub.equals("remove-pass")) {
            if (args.length < 2) {
                sender.sendMessage(t("messages.use-remove"));
                return true;
            }
            try {
                passportManager.getDb().removePassport(args[1]);
                String msg = passportManager.getMessagesConfig().getString("messages.passport-removed")
                        .replace("{target}", args[1]);
                sender.sendMessage(ChatColor.translateAlternateColorCodes('&', msg));
            } catch (SQLException e) {
                e.printStackTrace();
                sender.sendMessage(t("messages.passport-remove-error"));
            }
        } else if (sub.equals("view")) {
            if (args.length < 2) {
                sender.sendMessage(t("messages.use-view"));
                return true;
            }
            if (passportManager.getDb().getPassportData(args[1]).isEmpty()) {
                sender.sendMessage(t("messages.passport-not-found"));
                return true;
            }
            if (!(sender instanceof Player p)) {
                sender.sendMessage(t("messages.only-player"));
                return true;
            }
            passportManager.openPassportInventory(p, args[1]);
        } else {
            sender.sendMessage(t("messages.unknown-subcommand"));
        }
        return true;
    }
}
