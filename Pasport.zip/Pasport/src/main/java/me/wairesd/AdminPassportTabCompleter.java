package me.wairesd;

import org.bukkit.Bukkit;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.List;
import java.util.stream.Collectors;

public class AdminPassportTabCompleter implements TabCompleter {
    @Override
    public List<String> onTabComplete(CommandSender sender, org.bukkit.command.Command command, String alias, String[] args) {
        return switch (args.length) {
            case 1 -> List.of("remove-pass", "reload");
            case 2 -> args[0].equalsIgnoreCase("remove-pass")
                    ? Bukkit.getOnlinePlayers().stream().map(Player::getName).collect(Collectors.toList())
                    : List.of();
            default -> List.of();
        };
    }
}
