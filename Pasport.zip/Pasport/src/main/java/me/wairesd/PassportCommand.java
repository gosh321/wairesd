package me.wairesd;

import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import java.util.Locale;

public class PassportCommand implements CommandExecutor {
    private final PassportManager passportManager;

    public PassportCommand(PassportManager passportManager) {
        this.passportManager = passportManager;
    }

    private String t(String key) {
        return MessageUtils.getMessage(passportManager.getMessagesConfig(), key);
    }

    private String t(String key, String placeholder, String value) {
        return t(key).replace(placeholder, value);
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player p)) {
            sender.sendMessage(t("messages.only-player"));
            return true;
        }
        var config = passportManager.getMessagesConfig();
        if (config.getBoolean("perm-required", false) && !p.hasPermission("passport.use")) {
            p.sendMessage(t("messages.no-permission"));
            return true;
        }
        passportManager.initPassportIfNeeded(p);
        if (args.length == 0) {
            passportManager.openPassportInventory(p, p.getName());
            return true;
        }
        String sub = args[0].toLowerCase(Locale.ROOT);
        switch (sub) {
            case "view" -> {
                if (args.length < 2) {
                    p.sendMessage(t("messages.use-view"));
                    return true;
                }
                if (passportManager.getDb().getPassportData(args[1]).isEmpty()) {
                    p.sendMessage(t("messages.passport-not-found", "{target}", args[1]));
                    return true;
                }
                passportManager.openPassportInventory(p, args[1]);
            }
            case "age" -> {
                if (args.length < 2) {
                    p.sendMessage(t("messages.use-age"));
                    return true;
                }
                try {
                    int age = Integer.parseInt(args[1]);
                    if (age < 0 || age > 100) {
                        p.sendMessage(t("messages.age-range"));
                        return true;
                    }
                    passportManager.getDb().updatePassportData(p.getName(), "age", String.valueOf(age));
                    p.sendMessage(t("messages.age-set"));
                } catch (NumberFormatException e) {
                    p.sendMessage(t("messages.age-number"));
                }
            }
            case "gender" -> {
                if (args.length < 2) {
                    p.sendMessage(t("messages.use-gender"));
                    return true;
                }
                String gender = args[1].toLowerCase(Locale.ROOT);
                if (!gender.equals("male") && !gender.equals("female")) {
                    p.sendMessage(t("messages.gender-invalid"));
                    return true;
                }
                passportManager.getDb().updatePassportData(p.getName(), "gender", gender);
                p.sendMessage(t("messages.gender-set"));
            }
            case "vk", "tg", "ds" -> {
                if (args.length < 2) {
                    p.sendMessage(t("messages.use-social", "{SOCIAL}", passportManager.getSocialName(sub)));
                    return true;
                }
                passportManager.getDb().updatePassportData(p.getName(), sub, args[1]);
                p.sendMessage(t("messages.social-set", "{SOCIAL}", passportManager.getSocialName(sub)));
            }
            case "remove" -> {
                if (args.length < 2) {
                    p.sendMessage(t("messages.use-remove-social"));
                    return true;
                }
                String social = args[1].toLowerCase(Locale.ROOT);
                if (!social.equals("tg") && !social.equals("ds") && !social.equals("vk")) {
                    p.sendMessage(t("messages.social-invalid"));
                    return true;
                }
                String currentInfo = passportManager.getDb().getPassportData(p.getName()).get(social);
                if (currentInfo == null || currentInfo.isEmpty()) {
                    p.sendMessage(t("messages.social-not-found", "{SOCIAL}", passportManager.getSocialName(social)));
                    return true;
                }
                passportManager.getDb().updatePassportData(p.getName(), social, "");
                p.sendMessage(t("messages.social-removed", "{SOCIAL}", passportManager.getSocialName(social)));
            }
            default -> p.sendMessage(t("messages.unknown-subcommand"));
        }
        return true;
    }
}
