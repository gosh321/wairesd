package me.wairesd;

import net.dv8tion.jda.api.JDA;
import net.dv8tion.jda.api.JDABuilder;
import net.dv8tion.jda.api.entities.Activity;
import net.dv8tion.jda.api.interactions.commands.build.Commands;
import net.dv8tion.jda.api.interactions.commands.OptionType;
import net.dv8tion.jda.api.interactions.commands.build.OptionData;

public class DiscordBotManager {
    private JDA jda;
    private String token;
    private final PassportManager passportManager;
    private final PassportPlugin plugin;

    public DiscordBotManager(String token, PassportManager passportManager, PassportPlugin plugin) {
        this.token = token;
        this.passportManager = passportManager;
        this.plugin = plugin;
        connect();
    }

    public void connect() {
        try {
            if (jda != null) jda.shutdownNow();

            String activityMsg = passportManager.getMessagesConfig().getString("discord_msg.activity", "Passport Bot");
            String slashDescription = passportManager.getMessagesConfig().getString("discord_msg.slash-description", "Get a player's passport");
            String optionDescription = passportManager.getMessagesConfig().getString("discord_msg.option-description", "Player name");

            jda = JDABuilder.createDefault(token)
                    .setActivity(Activity.playing(activityMsg))
                    .addEventListeners(new DiscordBotListener(passportManager))
                    .build();
            jda.updateCommands().addCommands(
                    Commands.slash("passport", slashDescription)
                            .addOptions(new OptionData(OptionType.STRING, "player", optionDescription, false))
            ).queue();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void updateToken(String newToken) {
        token = newToken;
        connect();
    }

    public String getToken() {
        return token;
    }

    public void shutdown() {
        if (jda != null) jda.shutdownNow();
    }
}
