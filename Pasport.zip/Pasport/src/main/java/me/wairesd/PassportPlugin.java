package me.wairesd;

import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.util.HashMap;

public class PassportPlugin extends JavaPlugin {
    private FileConfiguration messagesConfig; // config with messages (messages.yml)
    private FileConfiguration settingsConfig;   // config with settings (settings.yml), now contains the statyses section
    private DatabaseManager dbManager;
    private PassportManager passportManager;
    private DiscordBotManager discordBotManager;

    @Override
    public void onEnable() {
        loadExternalConfigs();

        dbManager = new DatabaseManager(getDataFolder(), settingsConfig);
        dbManager.setupDatabase();
        passportManager = new PassportManager(dbManager, messagesConfig, settingsConfig, new HashMap<>());

        if (settingsConfig.getBoolean("discord.discord", false)) {
            String token = settingsConfig.getString("discord.token", "");
            discordBotManager = new DiscordBotManager(token, passportManager, this);
        }

        getCommand("admpasport").setExecutor(new AdminPassportCommand(passportManager, this, discordBotManager));
        getCommand("admpasport").setTabCompleter(new AdminPassportTabCompleter());
        getCommand("pasport").setExecutor(new PassportCommand(passportManager));
        getCommand("pasport").setTabCompleter(new PassportTabCompleter(messagesConfig));
    }

    @Override
    public void onDisable() {
        if (discordBotManager != null) discordBotManager.shutdown();
        dbManager.closeDatabase();
    }

    public void loadExternalConfigs() {
        File messagesFile = new File(getDataFolder(), "messages.yml");
        if (!messagesFile.exists()) {
            saveResource("messages.yml", false);
        }
        messagesConfig = YamlConfiguration.loadConfiguration(messagesFile);

        File settingsFile = new File(getDataFolder(), "settings.yml");
        if (!settingsFile.exists()) {
            saveResource("settings.yml", false);
        }
        settingsConfig = YamlConfiguration.loadConfiguration(settingsFile);
    }

    public void reloadAllConfigs() {
        loadExternalConfigs();
        passportManager.setMessagesConfig(messagesConfig);
        passportManager.setSettingsConfig(settingsConfig);
    }

    public FileConfiguration getMessagesConfig() {
        return messagesConfig;
    }

    public FileConfiguration getSettingsConfig() {
        return settingsConfig;
    }
}
