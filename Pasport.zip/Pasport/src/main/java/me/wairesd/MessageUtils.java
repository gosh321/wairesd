package me.wairesd;

import org.bukkit.ChatColor;
import org.bukkit.configuration.file.FileConfiguration;

public class MessageUtils {
    public static String getMessage(FileConfiguration config, String key) {
        String message = config.getString(key);
        if (message == null || message.isEmpty()) {
            message = "Message for key '" + key + "' not found! Edit this message.";
            config.set(key, message);
        }
        return ChatColor.translateAlternateColorCodes('&', message);
    }
}
