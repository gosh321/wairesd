package me.wairesd;

import net.dv8tion.jda.api.EmbedBuilder;
import net.dv8tion.jda.api.events.interaction.command.SlashCommandInteractionEvent;
import net.dv8tion.jda.api.hooks.ListenerAdapter;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import java.awt.Color;
import java.util.Map;

public class DiscordBotListener extends ListenerAdapter {
    private final PassportManager passportManager;

    public DiscordBotListener(PassportManager passportManager) {
        this.passportManager = passportManager;
    }

    @Override
    public void onSlashCommandInteraction(SlashCommandInteractionEvent event) {
        if (!"passport".equals(event.getName())) return;
        var option = event.getOption("player");
        var playerName = option != null ? option.getAsString() : event.getUser().getName();
        Map<String, String> data = passportManager.getDb().getPassportData(playerName);
        if (data.isEmpty()) {
            String replyMsg = passportManager.getMessagesConfig()
                    .getString("discord_msg.passport-not-found", "Passport for player {target} not found.")
                    .replace("{target}", playerName);
            event.reply(replyMsg).queue();
            return;
        }

        long storedPlayTime = 0;
        try {
            storedPlayTime = Long.parseLong(data.getOrDefault("playTime", "0"));
        } catch (NumberFormatException ignored) {}

        Player target = Bukkit.getPlayerExact(playerName);
        if (target != null && passportManager.getJoinTimes().containsKey(target.getUniqueId())) {
            long joinTime = passportManager.getJoinTimes().get(target.getUniqueId());
            long currentSessionMinutes = (System.currentTimeMillis() - joinTime) / 60000;
            storedPlayTime += currentSessionMinutes;
        }

        String chosenStatus = "<Status not specified>";
        var statSection = passportManager.getSettingsConfig().isConfigurationSection("statyses")
                ? passportManager.getSettingsConfig().getConfigurationSection("statyses")
                : null;
        if (target != null && statSection != null) {
            int highestPriority = -1;
            for (String key : statSection.getKeys(false)) {
                String perm = passportManager.getSettingsConfig().getString("statyses." + key + ".permission", "");
                if (!perm.isEmpty() && target.hasPermission(perm)) {
                    int priority = passportManager.getSettingsConfig().getInt("statyses." + key + ".priority", 0);
                    if (priority > highestPriority) {
                        highestPriority = priority;
                        chosenStatus = passportManager.getSettingsConfig().getString("statyses." + key + ".display_name", key);
                    }
                }
            }
        }

        String description = String.format(
                "**Age:** %s%n**Gender:** %s%n**Status:** %s%n**VK:** %s%n**Telegram:** %s%n" +
                        "**Discord:** %s%n**Join Date:** %s%n**Playtime (min):** %s%n**ID Number:** %s",
                data.getOrDefault("age", "<not specified>"),
                data.getOrDefault("gender", "<not specified>"),
                chosenStatus,
                data.getOrDefault("vk", "<not specified>"),
                data.getOrDefault("tg", "<not specified>"),
                data.getOrDefault("ds", "<not specified>"),
                data.getOrDefault("firstJoin", "<not specified>"),
                String.valueOf(storedPlayTime),
                data.getOrDefault("passportNumber", "<not specified>")
        );

        String colorString = passportManager.getMessagesConfig().getString("discord_msg.embed-color", "#00FF00");
        Color embedColor;
        try {
            embedColor = Color.decode(colorString);
        } catch (NumberFormatException e) {
            embedColor = Color.GREEN;
        }

        String embedTitle = passportManager.getMessagesConfig()
                .getString("discord_msg.title", "Player {target}'s Passport")
                .replace("{target}", playerName);

        event.replyEmbeds(new EmbedBuilder()
                .setTitle(embedTitle)
                .setDescription(description)
                .setColor(embedColor)
                .build()).queue();
    }
}
