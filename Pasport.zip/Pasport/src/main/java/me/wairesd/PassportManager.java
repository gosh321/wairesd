package me.wairesd;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitRunnable;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

public class PassportManager {

    private final DatabaseManager db;
    private FileConfiguration messagesConfig; // config for texts (messages.yml)
    private FileConfiguration settingsConfig;   // config for settings (settings.yml) – now contains the statyses section
    private final Map<UUID, Long> joinTimes;
    private static final DateTimeFormatter FORMATTER = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");

    public PassportManager(DatabaseManager db, FileConfiguration messagesConfig, FileConfiguration settingsConfig, Map<UUID, Long> joinTimes) {
        this.db = db;
        this.messagesConfig = messagesConfig;
        this.settingsConfig = settingsConfig;
        this.joinTimes = joinTimes;
    }

    public void setMessagesConfig(FileConfiguration messagesConfig) {
        this.messagesConfig = messagesConfig;
    }

    public FileConfiguration getMessagesConfig() {
        return messagesConfig;
    }

    public void setSettingsConfig(FileConfiguration settingsConfig) {
        this.settingsConfig = settingsConfig;
    }

    public FileConfiguration getSettingsConfig() {
        return settingsConfig;
    }

    public DatabaseManager getDb() {
        return db;
    }

    public Map<UUID, Long> getJoinTimes() {
        return joinTimes;
    }

    public void initPassportIfNeeded(Player player) {
        if (db.getPassportData(player.getName()).isEmpty()) {
            String firstJoin = LocalDateTime.now().format(FORMATTER);
            String passportNumber = db.generatePassportNumber();
            db.insertPassport(player.getName(), firstJoin, passportNumber);
        }
    }

    public void updatePlayTime(Player player) {
        UUID uuid = player.getUniqueId();
        if (!joinTimes.containsKey(uuid)) return;
        long joinTime = joinTimes.remove(uuid);
        long sessionMinutes = (System.currentTimeMillis() - joinTime) / 60000;
        var data = db.getPassportData(player.getName());
        long total = 0;
        try {
            total = Long.parseLong(data.getOrDefault("playTime", "0"));
        } catch (NumberFormatException ignored) {}
        db.updatePassportData(player.getName(), "playTime", String.valueOf(total + sessionMinutes));
    }

    private String safe(String value, String def) {
        return (value == null || value.isEmpty()) ? def : value;
    }

    public void openPassportInventory(Player viewer, String targetName) {
        final Player targetPlayer = Bukkit.getPlayerExact(targetName);
        if (targetPlayer != null) {
            initPassportIfNeeded(targetPlayer);
        }
        var data = db.getPassportData(targetName);

        final String age = safe(data.get("age"), "<Age not specified>");
        final String gender = safe(data.get("gender"), "<Gender not specified>");
        final String vk = safe(data.get("vk"), "<VK not specified>");
        final String tg = safe(data.get("tg"), "<Telegram not specified>");
        final String ds = safe(data.get("ds"), "<Discord not specified>");
        final String firstJoin = safe(data.get("firstJoin"), "<date>");

        long storedPlayTime = 0;
        try {
            storedPlayTime = Long.parseLong(data.getOrDefault("playTime", "0"));
        } catch (NumberFormatException e) {
            storedPlayTime = 0;
        }
        final long storedPlayTimeFinal = storedPlayTime;

        long livePlayTime = storedPlayTime;
        if (targetPlayer != null && joinTimes.containsKey(targetPlayer.getUniqueId())) {
            long currentSessionMinutes = (System.currentTimeMillis() - joinTimes.get(targetPlayer.getUniqueId())) / 60000;
            livePlayTime += currentSessionMinutes;
        }
        final String playTime = String.valueOf(livePlayTime);

        final String passportNumber = safe(data.get("passportNumber"), "#0000000000");

        // Using settingsConfig to determine statuses
        Player permissionCheck = (targetPlayer != null) ? targetPlayer : viewer;
        String chosenStatus = "<Status not specified>";
        int highestPriority = -1;
        if (settingsConfig.isConfigurationSection("statyses")) {
            for (String key : settingsConfig.getConfigurationSection("statyses").getKeys(false)) {
                String perm = settingsConfig.getString("statyses." + key + ".permission", "");
                if (!perm.isEmpty() && permissionCheck.hasPermission(perm)) {
                    int priority = settingsConfig.getInt("statyses." + key + ".priority", 0);
                    if (priority > highestPriority) {
                        highestPriority = priority;
                        chosenStatus = settingsConfig.getString("statyses." + key + ".display_name", key);
                    }
                }
            }
        }
        final String chosenStatusFinal = chosenStatus;

        String title = ChatColor.translateAlternateColorCodes('&', messagesConfig.getString("messages.passport.title", "&aPassport"));
        final String titleFinal = title;
        Inventory inv = Bukkit.createInventory(null, 9, titleFinal);

        ItemStack glass = new ItemStack(Material.GRAY_STAINED_GLASS_PANE);
        ItemMeta glassMeta = glass.getItemMeta();
        glassMeta.setDisplayName(" ");
        glass.setItemMeta(glassMeta);
        for (int i = 0; i < 9; i++) {
            inv.setItem(i, glass);
        }

        ItemStack book = new ItemStack(Material.BOOK);
        ItemMeta bookMeta = book.getItemMeta();
        bookMeta.setDisplayName(ChatColor.translateAlternateColorCodes('&',
                messagesConfig.getString("messages.passport.book.display", "&a&lPassport")));
        List<String> bookLore = new ArrayList<>();
        for (String line : messagesConfig.getStringList("messages.passport.book.lore")) {
            bookLore.add(ChatColor.translateAlternateColorCodes('&', line
                    .replace("{player}", targetName)
                    .replace("{gender}", gender)
                    .replace("{age}", age)
                    .replace("{on-a-server-with}", firstJoin)
                    .replace("{time-play}", playTime)
                    .replace("{humber-pass}", passportNumber)
                    .replace("{statys}", chosenStatusFinal)
                    .replace("{discord}", ds)
                    .replace("{tg}", tg)
                    .replace("{vk}", vk)));
        }
        bookMeta.setLore(bookLore);
        book.setItemMeta(bookMeta);

        ItemStack paper = new ItemStack(Material.PAPER);
        ItemMeta paperMeta = paper.getItemMeta();
        paperMeta.setDisplayName(ChatColor.translateAlternateColorCodes('&',
                messagesConfig.getString("messages.passport.paper.display", "&a&lDescription")));
        List<String> paperLore = new ArrayList<>();
        for (String line : messagesConfig.getStringList("messages.passport.paper.lore")) {
            paperLore.add(ChatColor.translateAlternateColorCodes('&', line));
        }
        paperMeta.setLore(paperLore);
        paper.setItemMeta(paperMeta);

        inv.setItem(4, book);
        inv.setItem(8, paper);
        viewer.openInventory(inv);

        new BukkitRunnable() {
            @Override
            public void run() {
                if (!viewer.getOpenInventory().getTitle().equals(titleFinal)) {
                    cancel();
                    return;
                }
                long updatedLivePlayTime = storedPlayTimeFinal;
                if (targetPlayer != null && joinTimes.containsKey(targetPlayer.getUniqueId())) {
                    long currentSessionMinutes = (System.currentTimeMillis() - joinTimes.get(targetPlayer.getUniqueId())) / 60000;
                    updatedLivePlayTime += currentSessionMinutes;
                }
                List<String> updatedLore = new ArrayList<>();
                for (String line : messagesConfig.getStringList("messages.passport.book.lore")) {
                    updatedLore.add(ChatColor.translateAlternateColorCodes('&', line
                            .replace("{player}", targetName)
                            .replace("{gender}", gender)
                            .replace("{age}", age)
                            .replace("{on-a-server-with}", firstJoin)
                            .replace("{time-play}", String.valueOf(updatedLivePlayTime))
                            .replace("{humber-pass}", passportNumber)
                            .replace("{statys}", chosenStatusFinal)
                            .replace("{discord}", ds)
                            .replace("{tg}", tg)
                            .replace("{vk}", vk)));
                }
                bookMeta.setLore(updatedLore);
                book.setItemMeta(bookMeta);
                inv.setItem(4, book);
                viewer.updateInventory();
            }
        }.runTaskTimer(JavaPlugin.getPlugin(PassportPlugin.class), 20L, 20L);
    }

    public String getSocialName(String social) {
        return switch (social.toLowerCase()) {
            case "tg" -> "Telegram";
            case "ds" -> "Discord";
            case "vk" -> "VK";
            default -> social;
        };
    }
}
