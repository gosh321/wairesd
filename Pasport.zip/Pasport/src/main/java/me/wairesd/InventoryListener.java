package me.wairesd;

import org.bukkit.ChatColor;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;

public class InventoryListener implements Listener {
    private final String title;

    public InventoryListener(FileConfiguration config) {
        this.title = ChatColor.translateAlternateColorCodes('&',
                config.getString("messages.passport.title", "&aPassport"));
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        if (event.getView().getTitle().equals(title)) {
            event.setCancelled(true);
        }
    }
}
